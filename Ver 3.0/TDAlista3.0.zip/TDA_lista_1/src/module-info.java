/**
 * 
 */
/**
 * 
 */
module TDA_lista {
    requires java.desktop;
    requires java.logging;
}